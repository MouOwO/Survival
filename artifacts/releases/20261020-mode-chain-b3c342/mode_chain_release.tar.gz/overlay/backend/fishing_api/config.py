from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


DATABASE_ROOT = Path(__file__).resolve().parents[2]


class ConfigError(ValueError):
    pass


def _positive_int(name: str, default: str) -> int:
    try:
        value = int(os.environ.get(name, default))
    except ValueError as exc:
        raise ConfigError(f"{name} must be an integer") from exc
    if value <= 0:
        raise ConfigError(f"{name} must be positive")
    return value


def _boolean(name: str, default: str = "0") -> bool:
    value = os.environ.get(name, default)
    if value not in {"0", "1"}:
        raise ConfigError(f"{name} must be 0 or 1")
    return value == "1"


def _postgres_dsn() -> str:
    direct = os.environ.get("POSTGRES_DSN", "").strip()
    filename = os.environ.get("POSTGRES_DSN_FILE", "").strip()
    if direct and filename:
        raise ConfigError("configure only POSTGRES_DSN or POSTGRES_DSN_FILE")
    if not filename:
        return direct
    try:
        with Path(filename).expanduser().open("r", encoding="utf-8") as stream:
            value = stream.read(65537)
        if not value.strip() or len(value) > 65536 or "\x00" in value:
            raise ValueError
        return value.strip()
    except (OSError, UnicodeError, ValueError):
        raise ConfigError("POSTGRES_DSN_FILE must be a readable, nonempty connection file") from None


@dataclass(frozen=True)
class Settings:
    host: str
    port: int
    api_token: str = field(repr=False)
    supabase_url: str = field(repr=False)
    supabase_key: str = field(repr=False)
    account_id_pepper: str = field(repr=False)
    reward_csv: Path
    rule_csv: Path
    gameplay_stats_csv: Path
    request_timeout_seconds: int
    database_backend: str = "supabase"
    postgres_dsn: str = field(default="", repr=False)
    postgres_connect_timeout_seconds: int = 3
    postgres_statement_timeout_ms: int = 5000
    postgres_lock_timeout_ms: int = 1000
    postgres_max_concurrency: int = 4
    http_max_concurrency: int = 8
    http_client_timeout_seconds: int = 5
    http_request_deadline_seconds: int = 20
    payment_mode: str = "test"
    archive_http: bool = False
    addon_root: Path | None = None
    archive_lua_path: str = "lua5.1"

    @classmethod
    def from_env(cls) -> "Settings":
        addon_root_raw = os.environ.get("SURVIVAL_ADDON_ROOT", "")
        addon_root = Path(addon_root_raw).expanduser().resolve() if addon_root_raw else None

        def csv_path(name: str, default: str) -> Path:
            configured = os.environ.get(name, "")
            if configured:
                path = Path(configured).expanduser()
                return (path if path.is_absolute() else DATABASE_ROOT / path).resolve()
            if addon_root is None:
                raise ConfigError("SURVIVAL_ADDON_ROOT is required")
            return (addon_root / default).resolve()

        settings = cls(
            host=os.environ.get("FISHING_API_HOST", "127.0.0.1"),
            port=_positive_int("FISHING_API_PORT", "8765"),
            api_token=os.environ.get("FISHING_API_TOKEN", ""),
            supabase_url=os.environ.get("SUPABASE_URL", "").rstrip("/"),
            supabase_key=(os.environ.get("SUPABASE_SECRET_KEY", "")
                          or os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")),
            account_id_pepper=os.environ.get("FISHING_ACCOUNT_ID_PEPPER", ""),
            reward_csv=csv_path(
                "FISHING_REWARD_CSV",
                "data/csv/玩家档案系统/star_blessing_reward_definitions.csv",
            ),
            rule_csv=csv_path(
                "FISHING_RULE_CSV",
                "data/csv/玩家档案系统/fishing_system_rules.csv",
            ),
            gameplay_stats_csv=csv_path(
                "GAMEPLAY_STATS_CSV",
                "data/csv/玩家档案系统/player_gameplay_stats.csv",
            ),
            request_timeout_seconds=_positive_int(
                "FISHING_REQUEST_TIMEOUT_SECONDS", "20"
            ),
            database_backend=os.environ.get("FISHING_DATABASE_BACKEND", "supabase"),
            postgres_dsn=_postgres_dsn(),
            postgres_connect_timeout_seconds=_positive_int("POSTGRES_CONNECT_TIMEOUT_SECONDS", "3"),
            postgres_statement_timeout_ms=_positive_int("POSTGRES_STATEMENT_TIMEOUT_MS", "5000"),
            postgres_lock_timeout_ms=_positive_int("POSTGRES_LOCK_TIMEOUT_MS", "1000"),
            postgres_max_concurrency=_positive_int("POSTGRES_MAX_CONCURRENCY", "4"),
            http_max_concurrency=_positive_int("FISHING_HTTP_MAX_CONCURRENCY", "8"),
            http_client_timeout_seconds=_positive_int("FISHING_HTTP_CLIENT_TIMEOUT_SECONDS", "5"),
            http_request_deadline_seconds=_positive_int("FISHING_HTTP_REQUEST_DEADLINE_SECONDS", "20"),
            payment_mode=os.environ.get("PAYMENT_MODE", "test"),
            archive_http=_boolean("SURVIVAL_ARCHIVE_HTTP"),
            addon_root=addon_root,
            archive_lua_path=os.environ.get("ARCHIVE_LUA_PATH", "lua5.1"),
        )
        settings.validate()
        return settings

    def validate(self) -> None:
        if self.host not in {"127.0.0.1", "localhost", "::1"}:
            raise ConfigError("FISHING_API_HOST must be loopback-only")
        if len(self.api_token) < 24:
            raise ConfigError("FISHING_API_TOKEN must contain at least 24 characters")
        if self.database_backend not in {"supabase", "postgres"}:
            raise ConfigError("FISHING_DATABASE_BACKEND must be supabase or postgres")
        if self.payment_mode != "test":
            raise ConfigError("PAYMENT_MODE must be test; paid operation is not enabled")
        if self.database_backend == "supabase":
            if not self.supabase_url.startswith("https://"):
                raise ConfigError("SUPABASE_URL must use https")
            if not self.supabase_key:
                raise ConfigError("SUPABASE_SECRET_KEY or SUPABASE_SERVICE_ROLE_KEY is required")
        elif not self.postgres_dsn:
            raise ConfigError("POSTGRES_DSN or POSTGRES_DSN_FILE is required")
        limits = (
            ("FISHING_API_PORT", self.port, 1, 65535),
            ("FISHING_REQUEST_TIMEOUT_SECONDS", self.request_timeout_seconds, 1, 120),
            ("POSTGRES_CONNECT_TIMEOUT_SECONDS", self.postgres_connect_timeout_seconds, 2, 10),
            ("POSTGRES_STATEMENT_TIMEOUT_MS", self.postgres_statement_timeout_ms, 100, 30000),
            ("POSTGRES_LOCK_TIMEOUT_MS", self.postgres_lock_timeout_ms, 1, self.postgres_statement_timeout_ms),
            ("POSTGRES_MAX_CONCURRENCY", self.postgres_max_concurrency, 1, 16),
            ("FISHING_HTTP_MAX_CONCURRENCY", self.http_max_concurrency, 1, 32),
            ("FISHING_HTTP_CLIENT_TIMEOUT_SECONDS", self.http_client_timeout_seconds, 1, 30),
            ("FISHING_HTTP_REQUEST_DEADLINE_SECONDS", self.http_request_deadline_seconds, 1, 120),
        )
        for name, value, minimum, maximum in limits:
            if type(value) is not int or not minimum <= value <= maximum:
                raise ConfigError(f"{name} must be between {minimum} and {maximum}")
        if self.http_request_deadline_seconds < self.http_client_timeout_seconds:
            raise ConfigError("HTTP request deadline must be at least the client timeout")
        if self.archive_http and self.addon_root is None:
            raise ConfigError("SURVIVAL_ADDON_ROOT is required for archive HTTP")
        if len(self.account_id_pepper) < 32:
            raise ConfigError("FISHING_ACCOUNT_ID_PEPPER must contain at least 32 characters")
        if not self.reward_csv.is_file():
            raise ConfigError(f"reward CSV not found: {self.reward_csv}")
        if not self.rule_csv.is_file():
            raise ConfigError(f"fishing rule CSV not found: {self.rule_csv}")
        if not self.gameplay_stats_csv.is_file():
            raise ConfigError(f"gameplay stats CSV not found: {self.gameplay_stats_csv}")
